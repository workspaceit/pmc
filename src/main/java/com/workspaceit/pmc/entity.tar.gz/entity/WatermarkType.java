package com.workspaceit.pmc.entity;

/**
 * Created by shawon on 1/8/18.
 */


public enum WatermarkType { image, text }

