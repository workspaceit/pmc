package com.workspaceit.pmc.entity;

/**
 * Created by shawon on 1/8/18.
 */


public enum Placement { tl,tc,tr,cl,cc,cr,bl,bc,br }

