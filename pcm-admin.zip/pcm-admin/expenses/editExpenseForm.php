<?php 

    include "../../inc/db_connect.php";

    $expenseID = $_POST['expenseID']; 
	$expenseNameEdit = $_POST['expenseNameEdit'];
	$expenseCategoryEdit = $_POST['expenseCategoryEdit'];
	$expenseTotalEdit = $_POST['expenseTotalEdit'];
	$expensePurposeEdit = $_POST['expensePurposeEdit'];
	$expensePayerEdit = $_POST['expensePayerEdit'];
	$expensePayeeEdit = $_POST['expensePayeeEdit'];  
	$expenseAuthorizedByEdit = $_POST['expenseAuthorizedByEdit'];
	$expensePaymentMethodEdit = $_POST['expensePaymentMethodEdit'];
	$expenseTransactionIdEdit = $_POST['expenseTransactionIdEdit'];
	$expenseStatusEdit = $_POST['expenseStatusEdit'];  
	$expenseDateEdit = $_POST['expenseDateEdit'];


try{
	$query = $conn->prepare("UPDATE expenses SET exp_name=?, exp_category=?, exp_total=?, exp_purpose=?, exp_payer=?, exp_payee=?, exp_auth=?, exp_method=?, exp_transaction_id=?, exp_status=?,exp_date=?  WHERE exp_id=?");
	$query->bind_param('sidsssssiisi',$expenseNameEdit,$expenseCategoryEdit,$expenseTotalEdit,$expensePurposeEdit,$expensePayerEdit,$expensePayeeEdit,$expenseAuthorizedByEdit,$expensePaymentMethodEdit,$expenseTransactionIdEdit,$expenseStatusEdit,$expenseDateEdit,$expenseID);

	// $query = $conn->prepare("UPDATE expenses SET exp_name=?, exp_total=?, exp_purpose=?, exp_payer=?, exp_payee=?, exp_auth=?, exp_method=?, exp_transaction_id=?, exp_status=?,exp_date=?  WHERE exp_id=?");
	// $query->bind_param('sdsssssissi',$expenseNameEdit,$expenseTotalEdit,$expensePurposeEdit,$expensePayerEdit,$expensePayeeEdit,$expenseAuthorizedByEdit,$expensePaymentMethodEdit,$expenseTransactionIdEdit,$expenseStatusEdit,$expenseDateEdit,$expenseID);

	$query->execute();

	$query->close();
}
catch (Exception $e){
	echo 'Caught exception: ',  $e->getMessage(), "\n";
}
echo $expenseID."\n". $expenseNameEdit."\n".$expenseTotalEdit."\n".$expensePurposeEdit."\n".$expensePayerEdit."\n".$expensePayeeEdit."\n".$expenseAuthorizedByEdit."\n".$expensePaymentMethodEdit."\n".$expenseTransactionIdEdit."\n".$expenseStatusEdit."\n".$expenseDateEdit;   
?>

