<?php 

	include "../../inc/db_connect.php";

    $expenseID = $_POST['expenseID'];

	$query = $conn->prepare("SELECT exp_name,exp_category, exp_total,exp_purpose,exp_payer,exp_payee,exp_auth,exp_method,exp_transaction_id,exp_status,exp_date FROM expenses WHERE exp_id=?");

	// $query = $conn->prepare("SELECT exp_name, exp_total,exp_purpose,exp_payer,exp_payee,exp_auth,exp_method,exp_transaction_id,exp_status,exp_date FROM expenses WHERE exp_id=?");

	$query->bind_param('i',$expenseID);
	$query->execute();
	$query -> bind_result($exp_name,$exp_category,$exp_total,$exp_purpose,$exp_payer,$exp_payee,$exp_auth,$exp_method,$exp_transaction_id,$exp_status,$exp_date);

	// $query -> bind_result($exp_name,$exp_total,$exp_purpose,$exp_payer,$exp_payee,$exp_auth,$exp_method,$exp_transaction_id,$exp_status,$exp_date);
	$query->fetch();
	$query -> close();
    
	$editExpenseResult = array();
	$editExpenseResult['exp_name'] = $exp_name;
	$editExpenseResult['exp_category'] =$exp_category;
	$editExpenseResult['exp_total'] = $exp_total;
	$editExpenseResult['exp_purpose'] = $exp_purpose;
	$editExpenseResult['exp_payer'] = $exp_payer;
	$editExpenseResult['exp_payee'] = $exp_payee;
	$editExpenseResult['exp_auth'] = $exp_auth;
	$editExpenseResult['exp_method'] = $exp_method;
	$editExpenseResult['exp_transaction_id'] = $exp_transaction_id;
	$editExpenseResult['exp_status'] = $exp_status;
	$editExpenseResult['exp_date'] = $exp_date;
	
	$editExpenseResultJSON = json_encode($editExpenseResult);
    
    echo $editExpenseResultJSON;
?>