<?php 

    include "../../inc/db_connect.php";

	$expenseName = $_POST['expenseName'];
	$expenseCategory = $_POST['expenseCategory']; 
	$expenseTotal = $_POST['expenseTotal'];
	$expensePurpose = $_POST['expensePurpose'];
	$expensePayer = $_POST['expensePayer'];
	$expensePayee = $_POST['expensePayee'];  
	$expenseAuthorizedBy = $_POST['expenseAuthorizedBy'];
	$expensePaymentMethod = $_POST['expensePaymentMethod'];
	$expenseTransactionId = $_POST['expenseTransactionId'];
	$expenseStatus = $_POST['expenseStatus'];  
	$expenseDate = $_POST['expenseDate']; 
	
 

try{
	//for expense category
	$query = $conn->prepare("INSERT INTO expenses (exp_name, exp_category,exp_total,exp_purpose,exp_payer,exp_payee,exp_auth,exp_method,exp_transaction_id,exp_status,exp_date) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
	$query->bind_param('sidsssssiis',$expenseName,$expenseCategory,$expenseTotal,$expensePurpose,$expensePayer,$expensePayee,$expenseAuthorizedBy,$expensePaymentMethod,$expenseTransactionId,$expenseStatus,$expenseDate);


	// $query = $conn->prepare("INSERT INTO expenses (exp_name, exp_total,exp_purpose,exp_payer,exp_payee,exp_auth,exp_method,exp_transaction_id,exp_status,exp_date) VALUES (?,?,?,?,?,?,?,?,?,?)");
	// $query->bind_param('sdsssssiss',$expenseName,$expenseTotal,$expensePurpose,$expensePayer,$expensePayee,$expenseAuthorizedBy,$expensePaymentMethod,$expenseTransactionId,$expenseStatus,$expenseDate);
	$query->execute();

	$query->close();
}
catch (Exception $e){
	echo 'Caught exception: ',  $e->getMessage(), "\n";
}
echo $expenseName."<br>".$expenseTotal."<br>".$expensePurpose."<br>".$expensePayer."<br>".$expensePayee."<br>".$expenseAuthorizedBy."<br>".$expensePaymentMethod."<br>".$expenseTransactionId."<br>".$expenseStatus."<br>".$expenseDate;   
?>

