<?php 
    include "../../inc/db_connect.php";
    if(isset($_POST['change_status'])){ 
        
        $query = $conn->prepare("SELECT exp_status from expenses where exp_id=?");
      	$query->bind_param('i',$_POST['change_status']);
      	$query->execute();
		$query -> bind_result($exp_status);
		$query -> store_result();
		$query -> fetch();
		$query -> close();

		if($exp_status=='0') {
            $query = $conn->prepare("UPDATE expenses SET exp_status='1' where exp_id=?");
		    $query->bind_param('i',$_POST['change_status']);
		    $query->execute();

		    $query->close();
		    echo "Status changed to Paid";

		    //header("location: /");
		    
        } 
        else if ($exp_status=='1') {
          	$query = $conn->prepare("UPDATE expenses SET exp_status='0' where exp_id=?");
		    $query->bind_param('i',$_POST['change_status']);
		    $query->execute();

		    $query->close();
		    echo "Status changed to Unpaid";
          }  
        

		
	} 
	

?>