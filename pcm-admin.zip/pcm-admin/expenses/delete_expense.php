<?php 


	if(isset($_GET['delete']) && !isset($_GET['confirm'])){ 


      	$query = $conn->prepare("Select exp_name from expenses where exp_id=?");
      	$query->bind_param('i',$_GET['delete']);
      	$query->execute();
		$query -> bind_result($exp_name);
		$query -> store_result();
		$query -> fetch();
		$query -> close();

		?>

		<div class="alert text-center alert-danger">Are you sure you want to delete the expense <?php echo "<strong>".$exp_name."</strong>"; ?>?<a href="index.php?expenses&delete=<?php echo $_GET['delete']; ?>&confirm" class="btn btn-danger" style="margin-left:5px;">DELETE</a><a href="index.php?expenses" class="btn btn-success" style="margin-left:5px;">CANCEL</a></div>
	<?php 
	} 

	if (isset($_GET['delete']) && isset($_GET['confirm'])){
          //UPDATE expense active (column: exp_active) to = 0
          
          $query = $conn->prepare("UPDATE expenses SET exp_active=0 where exp_id=?");
	      $query->bind_param('i',$_GET['delete']);
	      $query->execute();

	      $query->close();
    }
    ?>