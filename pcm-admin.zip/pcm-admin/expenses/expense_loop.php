<?php
$query = $conn->prepare("SELECT e.exp_id, e.exp_name,c.cat_name, e.exp_total, e.exp_purpose, e.exp_payer, e.exp_payee, e.exp_auth, e.exp_method, e.exp_transaction_id, e.exp_date, e.exp_status FROM expenses e LEFT JOIN categories c ON e.exp_category = c.id WHERE e.exp_active = '1' AND e.exp_date <= CURRENT_DATE() ORDER BY e.exp_date DESC");

$query->execute();

$query->bind_result($exp_id, $exp_name, $exp_category, $exp_total, $exp_purpose, $exp_payer, $exp_payee, $exp_auth, $exp_method, $exp_transaction_id, $exp_date, $exp_status);
$query -> store_result();
while($query->fetch()){
	
	list($exp_date, $trash) = explode(" ", $exp_date);
	list($year, $month, $day) = explode("-", $exp_date);
	$exp_date = "$month/$day/$year";


	setlocale(LC_MONETARY, 'en_US');
    //$exp_total = money_format('%i', $exp_total);
    $exp_total = money_format('%!i', $exp_total);
    

	/* $latitude = 40.81741;
	$longitude = -72.97343;
	$requestaddress = file_get_contents("http://maps.googleapis.com/maps/api/geocode/json?latlng=$latitude,$longitude&sensor=true");
	echo $requestaddress;
	$json = json_decode($requestaddress);
	echo $full_address2 = $json->{'results'}[0]->{'formatted_address'};	
	*/
	include "views/expenses/expense_row.php";
}
$query->close();

?>
