<div class="modal fade" id="addExpensesModal" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">
					New Expense
				</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<form action="#" method="POST" id="addResponseModalForm">
                <div class="modal-body" id="addExpenseModalBody">						
					<h3>
						<center>
							Add Expense
						</center>
					</h3> 
                        <div class="form-group">
                        <label for="expense-name">Expense Name:</label>
						<input type="text" name="expense-name" id="expense-name" class="form-control" maxlength="200" required>
                    </div>

					<div class="form-group">
                        <label for="expense-category">Expense Category:</label>
						
						
						<select name="expense-category" id="expense-category" class="form-control" >
						
						<?php 
						include "controllers/categories/select_list.php";
						?>
						</select>
                    </div>

					<div class="form-group">
						<label for="expense-total">Total:</label>
						<input type="number" step="any" id="expense-total" class="form-control" name="expense-total" required>
					</div> 
                    
                    <div class="form-group">     
                        <label for="expense-purpose">Purpose:</label>
						<input type="text" id="expense-purpose" name="expense-purpose" class="form-control" maxlength="500">
					</div> 	
					
					<div class="form-group">    
					    <label for="expense-payer">Payer:</label>
						<input type="text" id="expense-payer" name="expense-payer" class="form-control" maxlength="120">
					</div>    
						
                    <div class="form-group">    
					    <label for="expense-payee">Payee:</label>
						<input type="text" id="expense-payee" name="expense-payee" class="form-control" maxlength="120">
					</div> 
						
                    <div class="form-group">    
					    <label for="expense-authorized-by">Authorized By:</label>
						<input type="text" id="expense-authorized-by" name="expense-authorized-by" class="form-control" maxlength="200">
					</div> 

					 <div class="form-group">    
					    <label for="expense-date">Date:</label>
					
						<input type="text" placeholder="YYYY-MM-DD" id="expense-date" name="expense-date" class="form-control" >
					</div>
					
					<div class="form-group">
						
					
					</div>

					<div class="form-group">    
					    <p>Payment Method:</p>
					    <select class="form-control" id="expense-payment-method">
						  <option>Bank</option>
						  <option>Credit Card</option>
						  <option>Debit Card</option>
						  <option>Cash</option>
						  <option>PayPal</option>
						  <option>Wire Transfer</option>
						  <option>Other</option>
						</select>
                    </div> 

                    <div class="form-group">    
					    <label for="expense-transaction-id">Transaction ID:</label>
						<input type="text" name="expense-transaction-id" id="expense-transaction-id" class="form-control" maxlength="200">
					</div>
                     
                    <div class="form-group">    
					    <p>Status:</p>
						<select class="form-control" id="expense-status" required>
						  <option value="0">Unpaid</option>
						  <option value="1">Paid</option>
						</select>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" id="saveExpenseBtn" class="btn btn-primary" style="margin-right:10px;" >
						Save Expense
					</button>
					<button type="button" id="modalClose" class="btn btn-secondary" data-dismiss="modal">
						Close
					</button>
				</div>
			</form>
		</div>
	</div>
</div>
