<div style="margin:25px;">
	<h1><i class="fa fa-dollar" style="padding-right:15px;"></i>Wubur<strong>Expenses</strong></h1>
	<div class="alert alert-info">All of your past & saved expenses are here, and your future expenses can be seen below. <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#addExpensesModal">Add Expense</a></div>
	
	<?php 

    include "controllers/expenses/delete_expense.php";
 ?>
	
	
	<table class='table table-bordered table-responsive'>
	<thead><tr>
	<th><i class="fa fa-hashtag" style="padding-right:5px;"></i>ID</th>	
	<th><i class="fa fa-calendar" style="padding-right:5px;"></i>Date</th>
	<th>Expense Name</th>
	<th><i class="fa fa-cogs" style="padding-right:5px;"></i>Category</th>
	<th><i class="fa fa-dollar" style="padding-right:5px;"></i>Total</th>
	<th><i class="fa fa-question" style="padding-right:5px;"></i>Purpose</th>
	<th><i class="fa fa-user" style="padding-right:5px;"></i>Payer</th>
	<th><i class="fa fa-users" style="padding-right:5px;"></i>Payee</th>	
	<th><i class="fa fa-exclamation" style="padding-right:5px;"></i>Authorized By</th>
	<th><i class="fa fa-institution" style="padding-right:5px;"></i>Method</th>	
	<th><i class="fa fa-hashtag" style="padding-right:5px;"></i>Transaction ID</th>	
	<th><i class="fa fa-check" style="padding-right:5px;"></i>Status</th>
    <th><i class="fa fa-cog" style="padding-right:5px;"></i>Options</th>
	
	</tr></thead>
	<?php include "controllers/expenses/expense_loop.php";  ?>
	
	</table>
</div>

<?php include "views/expenses/new_expense_modal.php"; ?>
<?php include "views/expenses/edit_expense_modal.php"; ?>
<?php include "controllers/expenses/change_status_expense.php";?>


<script type="text/javascript">


$('#expense-date , #expense-date-edit').datepicker({
	dateFormat: "yy-mm-dd"
});

var validationMsg="";
function addExpenseFormValidation(){
	if($("#expense-name").val().length<=0){
		validationMsg = "Name is required."
		return false;
	}

	if(!$("#expense-total").val()>0){
		validationMsg = "Total must be a positive number."
		return false;
	}
	if(!$("#expense-date").val()>0){
		validationMsg = "Date is required."
		return false;
	}
	return true;


}

function editExpenseFormValidation(){
	if($("#expense-name-edit").val().length<=0){
		validationMsg = "Name is required."
		return false;
	}

	if(!$("#expense-total-edit").val()>0){
		validationMsg = "Total must be a positive number."
		return false;
	}
	if(!$("#expense-date-edit").val()>0){
		validationMsg = "Date is required."
		return false;
	}
	return true;


}
	
$("#saveExpenseBtn").click(function(e){
	validationMsg="";
    if(!addExpenseFormValidation()){
    	alert(validationMsg);
    	e.preventDefault();
    	return;
    }
    $.ajax({
		method: "POST",
		url: "controllers/expenses/addExpenseForm.php",
		data: {
			expenseName:$("#expense-name").val(),
			expenseCategory:$("#expense-category").val(),
			expenseTotal:$("#expense-total").val(),
			expensePurpose:$("#expense-purpose").val(),
			expensePayer:$("#expense-payer").val(),
			expensePayee:$("#expense-payee").val(),
			expenseAuthorizedBy:$("#expense-authorized-by").val(),
			expensePaymentMethod:$("#expense-payment-method option:selected").val(),
			expenseTransactionId:$("#expense-transaction-id").val(),
			expenseStatus:$("#expense-status option:selected").val(),
			expenseDate:$("#expense-date").val()
		},
        success: function(response){
 			console.log(response);
			document.getElementById("modalClose").click();
        }
    });
    
 });
	
$(document).on("click",".edit-expense",function() {
	 var expenseID = $(this).attr("data-id");
	 $("#editExpenseID").val(expenseID);
	 $.ajax({
		method: "POST",
		url: "controllers/expenses/edit_expense.php",
		data: {
			expenseID:expenseID
		},
        success: function(response){
        	var ediExpenseResult = JSON.parse(response);
        	
        	$("#expense-name-edit").val(ediExpenseResult.exp_name);
        	$("#expense-category-edit").val(ediExpenseResult.exp_category);
            $("#expense-total-edit").val(ediExpenseResult.exp_total);
            $("#expense-purpose-edit").val(ediExpenseResult.exp_purpose);
            $("#expense-payer-edit").val(ediExpenseResult.exp_payee);
            $("#expense-payee-edit").val(ediExpenseResult.exp_payee);
            $("#expense-authorized-by-edit").val(ediExpenseResult.exp_auth);
            $("#expense-payment-method-edit").val(ediExpenseResult.exp_method);
            $("#expense-transaction-id-edit").val(ediExpenseResult.exp_transaction_id);
            $("#expense-status-edit").val(ediExpenseResult.exp_status);
            $("#expense-date-edit").val(ediExpenseResult.exp_date);
            
        }
    });
		
});


$("#saveExpenseBtnEdit").click(function(e){
	validationMsg="";
    if(!editExpenseFormValidation()){
    	alert(validationMsg);
    	e.preventDefault();
    	return;
    }
    $.ajax({
		method: "POST",
		url: "controllers/expenses/editExpenseForm.php",
		data: {
			expenseID:$("#editExpenseID").val(),
			expenseNameEdit:$("#expense-name-edit").val(),
			expenseCategoryEdit:$("#expense-category-edit").val(),
			expenseTotalEdit:$("#expense-total-edit").val(),
			expensePurposeEdit:$("#expense-purpose-edit").val(),
			expensePayerEdit:$("#expense-payer-edit").val(),
			expensePayeeEdit:$("#expense-payee-edit").val(),
			expenseAuthorizedByEdit:$("#expense-authorized-by-edit").val(),
			expensePaymentMethodEdit:$("#expense-payment-method-edit option:selected").val(),
			expenseTransactionIdEdit:$("#expense-transaction-id-edit").val(),
			expenseStatusEdit:$("#expense-status-edit option:selected").val(),
			expenseDateEdit:$("#expense-date-edit").val()
			
		},
        success: function(response){
 			console.log(response);
			document.getElementById("modalCloseEdit").click();
        }
    });
    
 });

$("#exp_change_status1").click(function(e){
	//"index.php?expenses&change_status='.$exp_id.'" 
	var exp_change_status_ID = $(this).attr("data-id");
	$.ajax({
		method: "POST",
		url: "controllers/expenses/change_status_expense.php",
		data: {
			change_status:exp_change_status_ID	
		},
        success: function(response){
 		    console.log(response);
 		    location.reload();
 		}
    });   
 });
  
 
 /*
 function changeStatus(){
	var exp_change_status_ID = $(this).attr("data-id");
	console.log(response);
	$.ajax({
		method: "POST",
		url: "controllers/expenses/change_status_expense.php",
		data: {
			change_status:exp_change_status_ID	
		},
        success: function(response){
 		    console.log(response);
 		    location.reload();
 		}
    }); 	 
 }
 */
 

$("#exp_change_status2").click(function(e) {
	//"index.php?expenses&change_status='.$exp_id.'" 
	var exp_change_status_ID = $(this).attr("data-id");
	$.ajax({
		method: "POST",
		url: "controllers/expenses/change_status_expense.php",
		data: {
			change_status:exp_change_status_ID
			
		},
        success: function(response){
 		    console.log(response);
		    location.reload();
        }
    });
    
 });


</script>
