<tr>
<td><?php echo $exp_id ?></td>
<td><?php echo $exp_date ?></td>
<td><?php echo $exp_name ?></td>
<td><?php echo $exp_category ?></td>
<td><?php echo "$".$exp_total ?></td>
<td><?php echo $exp_purpose ?></td>
<td><?php echo $exp_payer ?></td>
<td><?php echo $exp_payee ?></td>
<td><?php echo $exp_auth ?></td>
<td><?php echo $exp_method ?></td>
<td><?php echo $exp_transaction_id ?></td>
<td><?php if($exp_status=='1'){
	echo '<button type="button" id="exp_change_status1" data-id="'.$exp_id.'" class="btn btn-success">Paid</button>';
}
else if($exp_status=='0'){
	echo '<button type="button" id="exp_change_status2" data-id="'.$exp_id.'" class="btn btn-danger">Unpaid</button>';
}
else {echo $exp_status; }?></td>
<td><p style="display: inline-flex;"><button class="btn btn-success edit-expense" style="margin-right:5px;" data-id="<?php echo $exp_id ?>" data-toggle="modal" data-target="#editExpensesModal"><i class="fa fa-pencil"></i></button>​<a href="index.php?expenses&delete=<?php echo $exp_id; ?>" class="btn btn-danger">X</a></p>​</td>
</tr>
