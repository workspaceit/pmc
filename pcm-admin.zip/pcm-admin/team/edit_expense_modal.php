<div class="modal fade" id="editExpensesModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Edit Expense</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
			<form action="#" method="POST" id="editResponseModalForm">
        
                <div class="modal-body" id="editExpenseModalBody">						
						<h3><center>Edit Expense</center></h3>
						<input type="hidden" name="editExpenseID" id="editExpenseID">
 
						<div class="form-group">
                            <label for="expense-name">Expense Name:</label>
							<input type="text" value="" name="expense-name" id="expense-name-edit" class="form-control" maxlength="200" required>
                        </div>
						
							<div class="form-group">
                            <label for="expense-category">Expense Category:</label>
							<select name="expense-category" id="expense-category-edit" class="form-control" >
							<?php 
    								include "controllers/categories/select_list.php";
  							?>
							</select>

                        </div>

						<div class="form-group">
							<label for="expense-total">Total:</label>
							<input type="number" step="any" id="expense-total-edit" class="form-control" name="expense-total" required>
						</div> 
                        
                        <div class="form-group">     
                            <label for="expense-purpose">Purpose:</label>
							<input type="text" id="expense-purpose-edit" name="expense-purpose" class="form-control" maxlength="500">
						</div> 	
						
						<div class="form-group">    
						    <label for="expense-payer">Payer:</label>
							<input type="text" id="expense-payer-edit" name="expense-payer" class="form-control" maxlength="120">
						</div>    
							
                        <div class="form-group">    
						    <label for="expense-payee">Payee:</label>
							<input type="text" id="expense-payee-edit" name="expense-payee" class="form-control" maxlength="120">
						</div> 
							
                        <div class="form-group">    
						    <label for="expense-authorized-by">Authorized By:</label>
							<input type="text" id="expense-authorized-by-edit" name="expense-authorized-by" class="form-control" maxlength="200">
						</div>

				   		 <div class="form-group">    
						    <label for="expense-date-edit">Date:</label>
							<input type="text" placeholder="YYYY-MM-DD" id="expense-date-edit" name="expense-date" class="form-control" >

						</div> 

						<div class="form-group">    
						    <p>Payment Method:</p>
						    <select class="form-control" id="expense-payment-method-edit">
							  <option>Bank</option>
							  <option>Credit Card</option>
							  <option>Debit Card</option>
							  <option>Cash</option>
							  <option>PayPal</option>
							  <option>Wire Transfer</option>
							  <option>Other</option>
							</select>
                        </div> 

                        <div class="form-group">    
						    <label for="expense-transaction-id">Transaction ID:</label>
							<input type="text" name="expense-transaction-id" id="expense-transaction-id-edit" class="form-control" maxlength="200">
						</div>

                        <div class="form-group">    
						    <p>Status:</p>
							<select class="form-control" id="expense-status-edit" required>
							  <option value="0">Unpaid</option>
							  <option value="1">Paid</option>
							</select>
						</div>
										

				</div>
				<div class="modal-footer">
					<button type="button" id="saveExpenseBtnEdit" class="btn btn-primary" style="margin-right:10px;" >Save Expense </button>
					<button type="button" id="modalCloseEdit" class="btn btn-secondary" data-dismiss="modal">Close</button>
				</div>
			</form>
    </div>
  </div>
</div>